"""Renderizado de figuras de publicación a partir de un ``FigureSpec``.

El ``FigureSpec`` es un modelo editable que describe *qué* mostrar (título,
ejes, colormap, barra de escala, anotaciones, tipografía). La GUI edita este
spec (campos de texto, dropdowns, arrastrar anotaciones) y vuelve a renderizar.
Así el "qué dibujar" vive en el core y el "cómo editarlo" en la GUI.

Requiere el extra ``viz`` (``pip install 'spmkit[viz]'``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from spmkit.core.models import SPMChannel
from spmkit.core.viz import colormaps


@dataclass
class Annotation:
    """Texto colocado sobre la figura (posición en fracción de ejes 0..1).

    Totalmente personalizable: color, tamaño, negrita/cursiva, familia, alineación de
    ancla (``ha``/``va``), justificado multilínea (``multialignment``), interlineado,
    rotación y un **fondo** opcional (color sólido o semitransparente vía ``bg_alpha``).
    """

    text: str
    x: float = 0.5
    y: float = 0.9
    fontsize: float = 12.0
    color: str = "white"
    ha: str = "center"  # ancla horizontal: left|center|right
    va: str = "center"  # ancla vertical: top|center|bottom|baseline
    multialignment: str = "center"  # justificado del bloque multilínea: left|center|right
    weight: str = "normal"  # normal|bold
    style: str = "normal"  # normal|italic
    family: str = "sans-serif"
    rotation: float = 0.0
    linespacing: float = 1.2  # interlineado
    bg_color: str | None = None  # fondo (None = sin fondo)
    bg_alpha: float = 1.0  # opacidad del fondo (0..1)
    bg_edge: str | None = None  # color del borde del fondo (None = sin borde)
    bg_pad: float = 0.4  # relleno del fondo (en fracción de fontsize)


def render_annotation(ax: Any, ann: Annotation) -> Any:
    """Dibuja ``ann`` en ``ax`` (coords de ejes) con todas sus propiedades.

    Fuente única de render de anotaciones (la usan ``render_channel`` y el editor de
    figuras de la GUI), para que la vista previa y la exportación coincidan.
    """
    bbox = None
    if ann.bg_color:
        bbox = {
            "boxstyle": f"round,pad={ann.bg_pad}",
            "facecolor": ann.bg_color,
            "alpha": ann.bg_alpha,
            "edgecolor": ann.bg_edge or "none",
        }
    return ax.text(
        ann.x,
        ann.y,
        ann.text,
        transform=ax.transAxes,
        fontsize=ann.fontsize,
        color=ann.color,
        ha=ann.ha,
        va=ann.va,
        multialignment=ann.multialignment,
        fontweight=ann.weight,
        fontstyle=ann.style,
        fontfamily=ann.family,
        rotation=ann.rotation,
        linespacing=ann.linespacing,
        bbox=bbox,
    )


@dataclass
class FigureSpec:
    """Descripción editable de una figura de imagen SPM."""

    title: str = ""
    xlabel: str = "x (µm)"
    ylabel: str = "y (µm)"
    colormap: str = "gold"
    vmin: float | None = None
    vmax: float | None = None
    show_colorbar: bool = True
    colorbar_label: str = ""
    show_scalebar: bool = True
    scalebar_color: str = "white"
    title_fontsize: float = 14.0
    label_fontsize: float = 11.0
    tick_fontsize: float = 9.0
    font_family: str = "DejaVu Sans"
    dpi: int = 300
    annotations: list[Annotation] = field(default_factory=list)


def render_channel(channel: SPMChannel, spec: FigureSpec | None = None, fig: Any = None) -> Any:
    """Construye una figura matplotlib del canal según ``spec``.

    Si se pasa ``fig`` (p.ej. la figura de un lienzo embebido) se dibuja sobre
    ella, manteniendo el vínculo figura↔lienzo (necesario para interacción).
    """
    spec = spec or FigureSpec(title=channel.name, colorbar_label=f"{channel.name} ({channel.unit})")
    import matplotlib

    matplotlib.use("Agg", force=False)
    import matplotlib.pyplot as plt

    with plt.rc_context({"font.family": spec.font_family, "font.size": spec.tick_fontsize}):
        if fig is None:
            fig, ax = plt.subplots(figsize=(5, 4), dpi=spec.dpi)
        else:
            fig.clear()
            ax = fig.add_subplot(111)
        if not channel.is_spatial:
            # Canal 1D/espectral (1×N o N×1): línea, no imagen. Evita el imshow degenerado
            # (extent con alto 0 → transformación singular) y da un espectro publicable.
            _render_spectrum(ax, channel, spec)
            fig.tight_layout()
            return fig
        extent = (0.0, channel.x_range * 1e6, 0.0, channel.y_range * 1e6)  # µm
        im = ax.imshow(
            channel.data,
            cmap=colormaps.get_cmap(spec.colormap),
            origin="upper",
            extent=extent,
            vmin=spec.vmin,
            vmax=spec.vmax,
            aspect="equal",
        )
        ax.set_title(spec.title, fontsize=spec.title_fontsize)
        ax.set_xlabel(spec.xlabel, fontsize=spec.label_fontsize)
        ax.set_ylabel(spec.ylabel, fontsize=spec.label_fontsize)

        if spec.show_colorbar:
            cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            cbar.set_label(spec.colorbar_label, fontsize=spec.label_fontsize)

        if spec.show_scalebar:
            _add_scalebar(ax, channel, spec.scalebar_color)

        for ann in spec.annotations:
            render_annotation(ax, ann)
        fig.tight_layout()
    return fig


def _render_spectrum(ax: Any, channel: SPMChannel, spec: FigureSpec) -> None:
    """Dibuja un canal 1D/espectral como línea: eje X = Dim0 (frecuencia) o índice."""
    import numpy as np

    y = np.asarray(channel.data, dtype=np.float64).ravel()
    x0 = float(channel.metadata.get("Dim0Min", 0.0))
    xr = float(channel.metadata.get("Dim0Range", 0.0))
    x = x0 + np.linspace(0.0, xr, y.size) if xr > 0 else np.arange(y.size, dtype=np.float64)
    ax.plot(x, y, color=colormaps.get_cmap(spec.colormap)(0.65), lw=1.2)
    ax.set_title(spec.title, fontsize=spec.title_fontsize)
    xname = str(channel.metadata.get("Dim0Name", "") or spec.xlabel or "Índice")
    xunit = str(channel.metadata.get("Dim0Unit", ""))
    ax.set_xlabel(f"{xname} ({xunit})" if xunit else xname, fontsize=spec.label_fontsize)
    yname = f"{channel.name} ({channel.unit})" if channel.unit else channel.name
    ax.set_ylabel(yname, fontsize=spec.label_fontsize)
    ax.grid(True, alpha=0.3)
    for ann in spec.annotations:
        render_annotation(ax, ann)


def save_figure(channel: SPMChannel, spec: FigureSpec, path: str | Path) -> Path:
    """Renderiza y guarda la figura (formato según extensión: png/svg/pdf)."""
    import matplotlib.pyplot as plt

    path = Path(path)
    fig = render_channel(channel, spec)
    fig.savefig(path, dpi=spec.dpi, bbox_inches="tight")
    plt.close(fig)
    return path


def render_grid(
    channels: list[SPMChannel],
    spec: FigureSpec | None = None,
    labels: list[str] | None = None,
    ncols: int | None = None,
    shared_scale: bool = True,
    fig: Any = None,
) -> Any:
    """Compone varias imágenes en un panel con **colorbar y escala compartidas**.

    Ideal para comparar 2–4 archivos lado a lado con la misma referencia de
    color (mismo gradiente) y una sola barra de escala.

    Args:
        channels: Lista de canales a comparar (2–4 típicamente).
        labels: Título de cada panel (por defecto, nombre del canal).
        ncols: Columnas de la grilla (por defecto, una fila).
        shared_scale: Si ``True``, usa el mismo ``vmin/vmax`` global en todos.
    """
    if not channels:
        raise ValueError("Se requiere al menos un canal")
    spec = spec or FigureSpec()
    import matplotlib

    matplotlib.use("Agg", force=False)
    import matplotlib.pyplot as plt
    import numpy as np

    n = len(channels)
    ncols = ncols or n
    nrows = int(np.ceil(n / ncols))
    labels = labels or [c.name for c in channels]

    vmin: float | None
    vmax: float | None
    if shared_scale and spec.vmin is None and spec.vmax is None:
        allvals = np.concatenate([c.data.ravel() for c in channels])
        vmin, vmax = float(np.nanmin(allvals)), float(np.nanmax(allvals))
    else:
        vmin, vmax = spec.vmin, spec.vmax

    cmap = colormaps.get_cmap(spec.colormap)
    with plt.rc_context({"font.family": spec.font_family, "font.size": spec.tick_fontsize}):
        if fig is None:
            fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3.6 * nrows), dpi=spec.dpi)
        else:
            fig.clear()
            fig.set_size_inches(4 * ncols, 3.6 * nrows)
            axes = fig.subplots(nrows, ncols)
        axes = np.atleast_1d(axes).ravel()
        im = None
        for ax, ch, label in zip(axes, channels, labels, strict=False):
            extent = (0.0, ch.x_range * 1e6, 0.0, ch.y_range * 1e6)
            im = ax.imshow(
                ch.data,
                cmap=cmap,
                origin="upper",
                extent=extent,
                vmin=vmin,
                vmax=vmax,
                aspect="equal",
            )
            ax.set_title(label, fontsize=spec.label_fontsize)
            ax.set_xlabel(spec.xlabel, fontsize=spec.tick_fontsize)
        for ax in axes[n:]:
            ax.axis("off")
        if spec.show_scalebar:
            # Una sola barra si todos los barridos miden igual; si no, una por
            # panel (correcto por escala). Evita una escala única engañosa.
            same_size = len({round(c.x_range, 12) for c in channels}) == 1
            if same_size:
                _add_scalebar(axes[0], channels[0], spec.scalebar_color)
            else:
                for ax, ch in zip(axes[:n], channels, strict=False):
                    _add_scalebar(ax, ch, spec.scalebar_color)
        if spec.title:
            fig.suptitle(spec.title, fontsize=spec.title_fontsize)
        if spec.show_colorbar and im is not None:
            fig.subplots_adjust(right=0.88)
            cax = fig.add_axes((0.90, 0.15, 0.02, 0.7))
            fig.colorbar(im, cax=cax).set_label(spec.colorbar_label, fontsize=spec.label_fontsize)
    return fig


def save_grid(channels: list[SPMChannel], spec: FigureSpec, path: str | Path, **kw: Any) -> Path:
    """Renderiza y guarda un panel comparativo multi-imagen."""
    import matplotlib.pyplot as plt

    path = Path(path)
    fig = render_grid(channels, spec, **kw)
    fig.savefig(path, dpi=spec.dpi, bbox_inches="tight")
    plt.close(fig)
    return path


def _add_scalebar(ax: Any, channel: SPMChannel, color: str) -> None:
    """Añade una barra de escala física usando matplotlib-scalebar si existe."""
    try:
        from matplotlib_scalebar.scalebar import ScaleBar
    except ImportError:  # pragma: no cover - scalebar opcional
        return
    # El eje ya está en µm (vía extent); cada unidad de dato = 1 µm.
    bar = ScaleBar(1.0, units="um", color=color, box_alpha=0, location="lower right")
    ax.add_artist(bar)
