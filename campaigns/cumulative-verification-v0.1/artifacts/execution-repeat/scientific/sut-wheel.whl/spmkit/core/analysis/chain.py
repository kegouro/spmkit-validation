"""Modelos de cadena polimérica (SMFS) — Worm-Like Chain (WLC) y Freely-Jointed Chain (FJC).

Espectroscopía de fuerza de molécula única: al estirar una proteína/ácido nucleico, la
fuerza de retracción sigue un modelo entrópico de cadena. Este módulo implementa dos
modelos y sus ajustes por recuperación de parámetros conocidos:

- **WLC** (Marko-Siggia + corrección de Bouchiat): ``F(x)`` explícita; recupera contorno
  ``L`` y persistencia ``lp``.
- **FJC** (Freely-Jointed Chain, Langevin): ``x(F) = L · L(F·b/k_BT)``; recupera contorno
  ``L`` y longitud de Kuhn ``b`` (con ``lp = b/2``). Como ``F(x)`` no tiene forma cerrada,
  el FJC se ajusta en el espacio de extensión ``x(F)`` (convención estándar).

**Ajuste separable** (igual que la detección de contacto): en ambos modelos la longitud
que multiplica es un factor **lineal** dada la longitud no lineal (``lp`` dado ``L`` en el
WLC; ``L`` dado ``b`` en el FJC) → solución cerrada por mínimos cuadrados y búsqueda 1D
robusta sobre el parámetro no lineal. numpy puro, sin solver.

Nota de alcance: los ajustes de cadena asumen la curva **ya corregida de línea base** en la
rama de retracción. Ese paso previo lo hace :func:`correct_retract_baseline` (quita offset +
inclinación por deflexión virtual usando la cola libre a gran separación); la detección de
eventos multi-pico es una etapa aparte. Validado por recuperación de parámetros conocidos
(``tests/validation/test_recovery``).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from spmkit.core.models import ForceCurve

#: Constante de Boltzmann (J/K).
_KB = 1.380649e-23

#: Coeficientes de la corrección de Bouchiat et al. (1999), a₂…a₇. Reducen el error del WLC
#: de Marko-Siggia (~10% cerca de la extensión total) a ~0.01%.
_BOUCHIAT = (-0.5164228, -2.737418, 16.07497, -38.87607, 39.49944, -14.17718)


def correct_retract_baseline(
    separation: np.ndarray,
    force: np.ndarray,
    baseline_fraction: float = 0.3,
) -> np.ndarray:
    """Corrige offset + inclinación (deflexión virtual) de la rama de retracción.

    En un retract, tras el despegue de la molécula la punta queda libre y la fuerza a **gran
    separación** debe ser cero: esa cola es la línea base real. Un retract crudo trae un
    artefacto **lineal** (offset del fotodetector + inclinación de la deflexión virtual). Se
    ajusta una recta ``force ~ separation`` a la cola libre (la fracción de mayor separación)
    y se resta de toda la curva → línea base plana ~0, preservando la altura de los eventos.

    Paso previo obligatorio a :func:`fit_wlc`/:func:`fit_fjc` sobre datos reales. numpy puro.
    """
    sep = np.asarray(separation, dtype=np.float64)
    f = np.asarray(force, dtype=np.float64)
    if sep.size < 5:
        raise ValueError("se requieren ≥5 puntos para corregir la línea base")
    n_base = max(3, int(sep.size * baseline_fraction))
    far = np.argsort(sep)[-n_base:]  # cola de mayor separación (punta despegada)
    s = sep - sep.mean()  # centrar mejora el condicionamiento del polyfit
    slope, offset = np.polyfit(s[far], f[far], 1)
    return f - (slope * s + offset)


@dataclass(frozen=True)
class ChainFit:
    """Resultado del ajuste de un modelo de cadena a un evento de estiramiento.

    ``rmse`` está en las unidades del eje ajustado: N para el WLC (ajusta ``F(x)``) y m
    para el FJC (ajusta ``x(F)``). ``kuhn_length`` solo lo llena el FJC (``lp = b/2``).
    """

    contour_length: float  # L (m)
    persistence_length: float  # lp (m)
    r_squared: float
    rmse: float  # N (WLC) o m (FJC) — ver docstring
    model: str
    temperature: float  # K
    n_fit: int
    kuhn_length: float | None = None  # b (m), solo FJC; lp = b/2

    def to_dict(self) -> dict:
        return asdict(self)


def _reduced(x: np.ndarray, contour_length: float) -> np.ndarray:
    """Extensión relativa r = x/L, acotada a [0, 0.999) para evitar el polo en r=1."""
    return np.clip(x / contour_length, 0.0, 0.999)


def wlc_force(
    x: np.ndarray,
    contour_length: float,
    persistence_length: float,
    temperature: float = 298.0,
    model: str = "bouchiat",
) -> np.ndarray:
    """Fuerza WLC (N) para extensión ``x`` (m), contorno ``L`` y persistencia ``lp`` (m).

    ``model="marko_siggia"`` usa la interpolación clásica; ``"bouchiat"`` añade la corrección
    polinómica de alta precisión.
    """
    kt = _KB * temperature
    r = _reduced(x, contour_length)
    g = 1.0 / (4.0 * (1.0 - r) ** 2) - 0.25 + r
    if model == "bouchiat":
        g = g + sum(a * r ** (i + 2) for i, a in enumerate(_BOUCHIAT))
    elif model != "marko_siggia":
        raise ValueError(f"model debe ser 'marko_siggia' o 'bouchiat'; se recibió {model!r}")
    return (kt / persistence_length) * g


def _shape(x: np.ndarray, contour_length: float, temperature: float, model: str) -> np.ndarray:
    """Forma ``g(x/L)`` del WLC **sin** el factor k_BT/lp (para el ajuste separable)."""
    kt = _KB * temperature
    return wlc_force(x, contour_length, 1.0, temperature, model) / kt  # lp=1 → g·k_BT; /kt → g


def fit_wlc(
    extension: np.ndarray,
    force: np.ndarray,
    model: str = "bouchiat",
    temperature: float = 298.0,
    length_bounds: tuple[float, float] | None = None,
) -> ChainFit:
    """Ajusta el WLC a ``(extension, force)`` y recupera ``L`` y ``lp``.

    Separable: para cada candidato ``L``, ``lp`` sale por mínimos cuadrados cerrados
    (``F = (k_BT/lp)·g(x/L)``); se busca ``L`` en 1D (grilla + refinamiento). Robusto y
    sin solver no lineal. La curva debe estar corregida de línea base (rama de retracción).
    """
    x = np.asarray(extension, dtype=np.float64)
    f = np.asarray(force, dtype=np.float64)
    finite = np.isfinite(x) & np.isfinite(f)
    x, f = x[finite], f[finite]
    if x.size < 5:
        raise ValueError("se requieren ≥5 puntos para ajustar el WLC")
    x_max = float(np.max(x))
    if x_max <= 0:
        raise ValueError("la extensión debe ser positiva")

    lo, hi = length_bounds or (x_max * 1.001, x_max * 3.0)

    def residual(contour_length: float) -> tuple[float, float]:
        g = _shape(x, contour_length, temperature, model)  # g(x/L)
        denom = float(np.sum(g * g))
        if denom <= 0.0:
            return np.inf, 0.0
        a = float(np.sum(g * f) / denom)  # a = k_BT/lp (factor lineal cerrado)
        pred = a * g
        return float(np.sum((f - pred) ** 2)), a

    best_l = min(np.linspace(lo, hi, 80), key=lambda ll: residual(ll)[0])
    step = (hi - lo) / 80.0
    for _ in range(4):  # refina L
        best_l = min(np.linspace(best_l - step, best_l + step, 21), key=lambda ll: residual(ll)[0])
        step /= 10.0

    ssr, a = residual(best_l)
    lp = _KB * temperature / a if a > 0 else np.nan
    sst = float(np.sum((f - f.mean()) ** 2))
    r2 = 1.0 - ssr / sst if sst > 0 else 1.0
    return ChainFit(
        contour_length=float(best_l),
        persistence_length=float(lp),
        r_squared=float(r2),
        rmse=float(np.sqrt(ssr / f.size)),
        model=model,
        temperature=temperature,
        n_fit=int(f.size),
    )


# --------------------------------------------------------------------- FJC (Langevin)


def _langevin(u: np.ndarray) -> np.ndarray:
    """Función de Langevin ``L(u) = coth(u) − 1/u``, con serie ``u/3`` cerca de 0.

    Evita el ``0/0`` en ``u→0`` (donde ``coth(u)−1/u → u/3``) sin generar avisos de
    división: la rama no tomada usa un ``u`` ficticio de 1.0.
    """
    u = np.asarray(u, dtype=np.float64)
    safe = np.where(u == 0.0, 1.0, u)
    return np.where(np.abs(u) < 1e-4, u / 3.0, 1.0 / np.tanh(safe) - 1.0 / safe)


def fjc_extension(
    force: np.ndarray,
    contour_length: float,
    kuhn_length: float,
    temperature: float = 298.0,
) -> np.ndarray:
    """Extensión FJC (m) para fuerza ``force`` (N), contorno ``L`` y Kuhn ``b`` (m).

    ``x(F) = L · L(F·b / k_BT)`` con ``L`` la función de Langevin. Modelo directo (la
    extensión es explícita en la fuerza; la inversa ``F(x)`` no tiene forma cerrada).
    """
    kt = _KB * temperature
    return contour_length * _langevin(np.asarray(force, dtype=np.float64) * kuhn_length / kt)


def fit_fjc(
    extension: np.ndarray,
    force: np.ndarray,
    temperature: float = 298.0,
    kuhn_bounds: tuple[float, float] | None = None,
) -> ChainFit:
    """Ajusta el FJC a ``(extension, force)`` y recupera ``L`` y la longitud de Kuhn ``b``.

    Separable en el espacio de extensión: para cada candidato ``b``, el contorno ``L`` sale
    por mínimos cuadrados cerrados (``x = L · L(F·b/k_BT)``); se busca ``b`` en 1D (grilla
    logarítmica + refinamiento), parametrizada por la fuerza reducida máxima ``u_max =
    F_max·b/k_BT`` (que controla la curvatura de Langevin). La curva debe estar corregida de
    línea base (rama de retracción). Devuelve ``lp = b/2`` en ``persistence_length``.
    """
    x = np.asarray(extension, dtype=np.float64)
    f = np.asarray(force, dtype=np.float64)
    finite = np.isfinite(x) & np.isfinite(f)
    x, f = x[finite], f[finite]
    if x.size < 5:
        raise ValueError("se requieren ≥5 puntos para ajustar el FJC")
    f_max = float(np.max(np.abs(f)))
    if f_max <= 0:
        raise ValueError("la fuerza debe tener magnitud positiva")

    kt = _KB * temperature
    b_scale = kt / f_max  # b tal que u_max = F_max·b/k_BT = 1
    # u_max ∈ [0.1, 200] cubre desde régimen casi lineal hasta saturación de Langevin.
    lo, hi = kuhn_bounds or (0.1 * b_scale, 200.0 * b_scale)

    def residual(kuhn: float) -> tuple[float, float]:
        g = _langevin(f * kuhn / kt)  # L(F·b/k_BT)
        denom = float(np.sum(g * g))
        if denom <= 0.0:
            return np.inf, 0.0
        length = float(np.sum(g * x) / denom)  # L = factor lineal cerrado
        return float(np.sum((x - length * g) ** 2)), length

    grid = np.geomspace(lo, hi, 80)  # escala → grilla logarítmica
    best_b = float(min(grid, key=lambda bb: residual(bb)[0]))
    step = best_b * 0.5
    for _ in range(5):  # refina b localmente
        cand = np.linspace(max(best_b - step, lo * 1e-3), best_b + step, 21)
        best_b = float(min(cand, key=lambda bb: residual(bb)[0]))
        step /= 5.0

    ssr, length = residual(best_b)
    sst = float(np.sum((x - x.mean()) ** 2))
    r2 = 1.0 - ssr / sst if sst > 0 else 1.0
    return ChainFit(
        contour_length=float(length),
        persistence_length=float(best_b / 2.0),  # lp = b/2
        r_squared=float(r2),
        rmse=float(np.sqrt(ssr / x.size)),  # RMSE en metros (ajuste en extensión)
        model="fjc",
        temperature=temperature,
        n_fit=int(x.size),
        kuhn_length=float(best_b),
    )


# ------------------------------------------------------- detección de eventos (multi-pico)


@dataclass(frozen=True)
class StretchEvent:
    """Un evento de estiramiento/ruptura en una rama de retracción.

    El ``peak_index`` es el punto de ruptura (máximo antes de la caída brusca); la región
    ``[start_index, peak_index]`` es el tramo de estiramiento ajustable con :func:`fit_wlc`/
    :func:`fit_fjc` (desde la ruptura anterior, o el inicio, hasta este pico).
    """

    start_index: int
    peak_index: int
    separation: float  # separación en el pico (m)
    force: float  # fuerza en el pico (N)
    prominence: float  # altura sobre el valle previo (N)


def detect_events(
    separation: np.ndarray,
    force: np.ndarray,
    baseline_fraction: float = 0.3,
    min_prominence_sigma: float = 5.0,
    min_height_sigma: float = 5.0,
) -> list[StretchEvent]:
    """Detecta eventos de ruptura en un retract **corregido de línea base**.

    Detección por **prominencia** (peakdet estilo Billauer), no por umbral sobre la fuerza
    cruda: un pico solo cuenta si (1) destaca ≥ ``min_prominence_sigma · σ`` sobre su valle
    adyacente **y** (2) se eleva ≥ ``min_height_sigma · σ`` sobre el baseline cero, con ``σ``
    estimada del ruido de la cola libre (mayor separación). El criterio (1) ignora pendientes
    suaves; el (2) descarta blips de ruido (el ruido puro apenas llega a ~3σ). Espera la curva
    ordenada por **separación creciente** (forma natural del retract).

    Devuelve los eventos en orden de separación; cada uno lleva su tramo ajustable
    ``[start_index, peak_index]`` (desde la ruptura real anterior hasta el pico).
    """
    sep = np.asarray(separation, dtype=np.float64)
    f = np.asarray(force, dtype=np.float64)
    if sep.size < 5:
        raise ValueError("se requieren ≥5 puntos para detectar eventos")
    n_base = max(3, int(sep.size * baseline_fraction))
    sigma = float(np.std(f[-n_base:]))  # ruido de la cola libre (gran separación)
    if sigma <= 0.0:
        sigma = float(np.std(f)) or 1.0  # datos sin ruido: usa la escala global
    delta = min_prominence_sigma * sigma
    height_floor = min_height_sigma * sigma

    # peakdet: registra un máximo cuando la fuerza cae ≥ delta por debajo de él. Al registrar,
    # ``mn`` es el valle que precede al pico → prominencia = mx − mn.
    candidates: list[tuple[int, float, float]] = []  # (índice, prominencia, fuerza en el pico)
    mn, mx = np.inf, -np.inf
    mx_pos = 0
    look_for_max = True
    for i in range(f.size):
        val = f[i]
        if val > mx:
            mx, mx_pos = val, i
        if val < mn:
            mn = val
        if look_for_max:
            if val < mx - delta:  # caída confirmada → ruptura en mx_pos
                candidates.append((mx_pos, float(mx - mn), float(mx)))
                mn = val
                look_for_max = False
        elif val > mn + delta:  # subió de nuevo → arranca otro evento
            mx, mx_pos = val, i
            look_for_max = True

    events: list[StretchEvent] = []
    prev = -1  # índice de la ruptura anterior aceptada; el tramo empieza en prev+1
    for pos, prom, peak_f in candidates:
        if peak_f < height_floor:  # blip de ruido: no define un evento ni el tramo siguiente
            continue
        events.append(
            StretchEvent(
                start_index=prev + 1,  # tras la ruptura anterior (no incluye su pico)
                peak_index=int(pos),
                separation=float(sep[pos]),
                force=peak_f,
                prominence=prom,
            )
        )
        prev = int(pos)
    return events


# ---------------------------------------------------------- orquestador SMFS de extremo a extremo


@dataclass(frozen=True)
class EventFit:
    """Un evento de ruptura junto al modelo de cadena ajustado a su tramo de estiramiento."""

    event: StretchEvent
    fit: ChainFit


def fit_chain_events(
    separation: np.ndarray,
    force: np.ndarray,
    model: str = "wlc",
    temperature: float = 298.0,
    baseline_fraction: float = 0.3,
    min_prominence_sigma: float = 5.0,
    min_height_sigma: float = 5.0,
    min_r_squared: float = 0.95,
    correct_baseline: bool = True,
    min_points: int = 8,
    wlc_model: str = "bouchiat",
) -> list[EventFit]:
    """Pipeline SMFS de extremo a extremo sobre una rama de retracción.

    Encadena las etapas ya validadas: (1) :func:`correct_retract_baseline` (offset+tilt de
    deflexión virtual), (2) :func:`detect_events` (rupturas por prominencia + piso de altura)
    y (3) ajuste de cada tramo ``[start, peak]`` con ``model`` (``"wlc"`` o ``"fjc"``). Aplica
    **control de calidad**: descarta los ajustes con ``r_squared < min_r_squared`` o con menos
    de ``min_points`` puntos. Devuelve, en orden de separación, los eventos aceptados con su fit.
    ``wlc_model`` (``"bouchiat"``/``"marko_siggia"``) elige la variante del WLC.

    Cada modelo ajusta la extensión relativa al inicio de su tramo (``x = sep − sep[start]``).
    """
    if model not in ("wlc", "fjc"):
        raise ValueError(f"model debe ser 'wlc' o 'fjc'; se recibió {model!r}")
    sep = np.asarray(separation, dtype=np.float64)
    f = np.asarray(force, dtype=np.float64)
    if correct_baseline:
        f = correct_retract_baseline(sep, f, baseline_fraction=baseline_fraction)

    events = detect_events(
        sep,
        f,
        baseline_fraction=baseline_fraction,
        min_prominence_sigma=min_prominence_sigma,
        min_height_sigma=min_height_sigma,
    )

    accepted: list[EventFit] = []
    for ev in events:
        sl = slice(ev.start_index, ev.peak_index + 1)
        x = sep[sl] - sep[ev.start_index]  # extensión desde el inicio del tramo
        fseg = f[sl]
        if x.size < min_points:
            continue
        try:
            fit = (
                fit_wlc(x, fseg, model=wlc_model, temperature=temperature)
                if model == "wlc"
                else fit_fjc(x, fseg, temperature=temperature)
            )
        except ValueError:
            continue  # tramo degenerado (sin fuerza positiva, etc.) → descartado por QC
        if fit.r_squared >= min_r_squared:
            accepted.append(EventFit(event=ev, fit=fit))
    return accepted


def analyze_retract(curve: ForceCurve, model: str = "wlc", **kwargs: object) -> list[EventFit]:
    """Corre el pipeline SMFS (:func:`fit_chain_events`) sobre la rama de retracción.

    Adaptador de la capa de modelo: extrae ``(separación, fuerza)`` del segmento de retract de
    una ``ForceCurve`` **ya calibrada** (con fuerza y separación calculadas) y delega en
    :func:`fit_chain_events`. Es la costura única que CLI y GUI reutilizan. ``**kwargs`` pasa a
    ``fit_chain_events`` (``min_r_squared``, ``correct_baseline``, umbrales…).
    """
    seg = curve.retract
    if seg is None:
        raise ValueError("la curva no tiene segmento de retracción")
    sep = seg.require_separation()
    force = seg.require_force()
    return fit_chain_events(sep, force, model=model, **kwargs)  # type: ignore[arg-type]
